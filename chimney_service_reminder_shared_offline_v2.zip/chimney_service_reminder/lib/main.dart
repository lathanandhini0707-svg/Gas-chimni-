import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

final notifications = FlutterLocalNotificationsPlugin();
final dateFmt = DateFormat('dd-MM-yyyy');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  await notifications.initialize(const InitializationSettings(android: android));
  runApp(const ChimneyApp());
}

DateTime addMonths(DateTime d, int months) {
  final y = d.year + ((d.month - 1 + months) ~/ 12);
  final m = ((d.month - 1 + months) % 12) + 1;
  final last = DateTime(y, m + 1, 0).day;
  return DateTime(y, m, d.day > last ? last : d.day);
}

class ChimneyApp extends StatelessWidget {
  const ChimneyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Chimney Service Reminder',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.orange),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (_, snap) => snap.data == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController(), password=TextEditingController();
  bool create=false, busy=false;
  String? error;
  Future<void> go() async {
    setState(()=>busy=true); error=null;
    try {
      if(create) await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
      else await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
    } on FirebaseAuthException catch(e){ setState(()=>error=e.message ?? e.code); }
    finally{ if(mounted)setState(()=>busy=false); }
  }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.home_work,size:64),const SizedBox(height:12),const Text('Chimney Service Reminder',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:24),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),if(error!=null)Padding(padding:const EdgeInsets.all(8),child:Text(error!,style:const TextStyle(color:Colors.red))),const SizedBox(height:12),FilledButton(onPressed:busy?null:go,child:Text(create?'Create Account':'Login')),TextButton(onPressed:busy?null:()=>setState(()=>create=!create),child:Text(create?'Already have account? Login':'Create new account'))]))));
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  final db=FirebaseFirestore.instance;
  String groupId='';
  final group=TextEditingController();
  Stream<QuerySnapshot<Map<String,dynamic>>> get stream => db.collection('groups').doc(groupId).collection('customers').orderBy('nextDate').snapshots();
  Future<void> setGroup() async { final g=group.text.trim(); if(g.isEmpty)return; setState(()=>groupId=g); await _saveGroup(g); }
  Future<void> _saveGroup(String g) async { await db.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).set({'groupId':g},SetOptions(merge:true)); }
  @override void initState(){super.initState(); _loadGroup();}
  Future<void> _loadGroup() async { final d=await db.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).get(); final g=(d.data()?['groupId']??'').toString(); if(g.isNotEmpty&&mounted)setState(()=>groupId=g); }
  Future<void> addCustomer() async { if(groupId.isEmpty){_askGroup();return;} await Navigator.push(context,MaterialPageRoute(builder:(_)=>AddCustomerPage(groupId:groupId))); }
  Future<void> _askGroup() async { group.clear(); await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Shared 2-person space'),content:TextField(controller:group,decoration:const InputDecoration(labelText:'Shared Group ID')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){setGroup();Navigator.pop(context);},child:const Text('Save'))])); }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Chimney Service Reminder'),actions:[IconButton(onPressed:_askGroup,icon:const Icon(Icons.group)),IconButton(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout))]),floatingActionButton:FloatingActionButton.extended(onPressed:addCustomer,icon:const Icon(Icons.person_add),label:const Text('Add Customer')),body:groupId.isEmpty?Center(child:FilledButton.icon(onPressed:_askGroup,icon:const Icon(Icons.group),label:const Text('Set Shared Group ID'))):StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:stream,builder:(c,s){if(s.hasError)return Center(child:Text('Sync error: ${s.error}'));if(!s.hasData)return const Center(child:CircularProgressIndicator());final docs=s.data!.docs;final total=docs.fold<double>(0,(a,d)=>a+(d.data()['paid']??0));final pending=docs.fold<double>(0,(a,d)=>a+((d.data()['amount']??0)-(d.data()['paid']??0)));final today=dateFmt.format(DateTime.now());final due=docs.where((d)=>d.data()['nextDate']==today).length;return ListView(padding:const EdgeInsets.all(16),children:[Row(children:[_card('Customers','${docs.length}',Icons.people),_card('Due Today','$due',Icons.notifications_active)]),Row(children:[_card('Collected','₹${total.toStringAsFixed(0)}',Icons.payments),_card('Pending','₹${pending.toStringAsFixed(0)}',Icons.pending_actions)]),const SizedBox(height:12),const Text('Shared Customers',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),...docs.map((d)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.home)),title:Text(d.data()['name']??''),subtitle:Text('Next: ${d.data()['nextDate']}\nAmount: ₹${(d.data()['amount']??0).toString()} • Paid: ₹${(d.data()['paid']??0).toString()}'),isThreeLine:true,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CustomerPage(groupId:groupId,id:d.id,data:d.data()))))) ]);}),);
  Widget _card(String a,String b,IconData i)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i),Text(a),Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))]))));
}

class AddCustomerPage extends StatefulWidget { final String groupId; const AddCustomerPage({super.key,required this.groupId}); @override State<AddCustomerPage> createState()=>_AddCustomerPageState(); }
class _AddCustomerPageState extends State<AddCustomerPage>{
  final name=TextEditingController(),phone=TextEditingController(),address=TextEditingController(),chimney=TextEditingController(),amount=TextEditingController(),paid=TextEditingController(),notes=TextEditingController(); DateTime serviceDate=DateTime.now();
  Future<void> save() async { if(name.text.trim().isEmpty)return; final next=addMonths(serviceDate,3); final doc=FirebaseFirestore.instance.collection('groups').doc(widget.groupId).collection('customers').doc(); await doc.set({'name':name.text.trim(),'phone':phone.text.trim(),'address':address.text.trim(),'chimney':chimney.text.trim(),'serviceDate':dateFmt.format(serviceDate),'nextDate':dateFmt.format(next),'amount':double.tryParse(amount.text)??0,'paid':double.tryParse(paid.text)??0,'notes':notes.text.trim(),'updatedAt':FieldValue.serverTimestamp(),'updatedBy':FirebaseAuth.instance.currentUser!.uid}); await doc.collection('services').add({'serviceDate':dateFmt.format(serviceDate),'amount':double.tryParse(amount.text)??0,'paid':double.tryParse(paid.text)??0,'notes':notes.text.trim(),'createdAt':FieldValue.serverTimestamp()}); if(mounted)Navigator.pop(context); }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Add Customer')),body:ListView(padding:const EdgeInsets.all(16),children:[_f(name,'Customer Name',Icons.person),_f(phone,'Mobile Number',Icons.phone,TextInputType.phone),_f(address,'Address',Icons.location_on),_f(chimney,'Chimney Details',Icons.kitchen),ListTile(contentPadding:EdgeInsets.zero,title:Text('Service Date: ${dateFmt.format(serviceDate)}'),trailing:const Icon(Icons.calendar_month),onTap:()async{final d=await showDatePicker(context:c,initialDate:serviceDate,firstDate:DateTime(2020),lastDate:DateTime(2100));if(d!=null)setState(()=>serviceDate=d);}),_f(amount,'Service Amount ₹',Icons.currency_rupee,TextInputType.number),_f(paid,'Amount Paid ₹',Icons.payments,TextInputType.number),_f(notes,'Notes',Icons.note),const SizedBox(height:10),FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:const Text('Save Customer'))]);
  Widget _f(TextEditingController x,String h,IconData i,[TextInputType? t])=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:x,keyboardType:t,decoration:InputDecoration(labelText:h,prefixIcon:Icon(i),border:const OutlineInputBorder())));
}

class CustomerPage extends StatelessWidget { final String groupId,id; final Map<String,dynamic> data; const CustomerPage({super.key,required this.groupId,required this.id,required this.data});
  Future<void> renew(BuildContext context) async { final today=DateTime.now(); final next=addMonths(today,3); final ref=FirebaseFirestore.instance.collection('groups').doc(groupId).collection('customers').doc(id); await ref.update({'serviceDate':dateFmt.format(today),'nextDate':dateFmt.format(next),'updatedAt':FieldValue.serverTimestamp(),'updatedBy':FirebaseAuth.instance.currentUser!.uid}); await ref.collection('services').add({'serviceDate':dateFmt.format(today),'amount':data['amount']??0,'paid':data['paid']??0,'notes':'Renewed service','createdAt':FieldValue.serverTimestamp()}); if(context.mounted)Navigator.pop(context); }
  Future<void> delete(BuildContext context) async { final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Delete customer?'),content:const Text('This will delete this customer from the shared space.'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Delete'))])); if(ok==true){await FirebaseFirestore.instance.collection('groups').doc(groupId).collection('customers').doc(id).delete();if(context.mounted)Navigator.pop(context);} }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(data['name']??''),actions:[IconButton(onPressed:()=>delete(c),icon:const Icon(Icons.delete_outline))]),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(data['name']??'',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(data['phone']??''),Text(data['address']??''),const Divider(),Text('Last Service: ${data['serviceDate']}'),Text('Next Service: ${data['nextDate']}'),Text('Amount: ₹${data['amount']??0}'),Text('Paid: ₹${data['paid']??0}'),Text('Balance: ₹${((data['amount']??0)-(data['paid']??0))}'),Text('Notes: ${data['notes']??''}')]))),FilledButton.icon(onPressed:()=>renew(c),icon:const Icon(Icons.autorenew),label:const Text('Renew Service — Next 3 Months')),const SizedBox(height:8),OutlinedButton.icon(onPressed:()async{final rows=await FirebaseFirestore.instance.collection('groups').doc(groupId).collection('customers').doc(id).collection('services').orderBy('createdAt',descending:true).get();if(c.mounted)showModalBottomSheet(context:c,builder:(_)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Service History',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),...rows.docs.map((r)=>ListTile(title:Text(r.data()['serviceDate'].toString()),subtitle:Text('Amount ₹${r.data()['amount']} • Paid ₹${r.data()['paid']}')))]));},icon:const Icon(Icons.history),label:const Text('View Service History'))]));
}
